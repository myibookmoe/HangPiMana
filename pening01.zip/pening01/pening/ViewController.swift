//
//  ViewController.swift
//  pening
//
//  Created by shah on 18/03/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

// Thanks to:
// MapKit - User Current Location tutorial by Muneeb Ali
// https://www.codementor.io/@muneebali/mapkit-user-current-location-10xdbyy1v3

// Reverse Geocoding with CLGeocoder by Bart Jacobs
// https://cocoacasts.com/reverse-geocoding-with-clgeocoder



import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var locationLabel: UILabel!
    
    lazy var geocoder = CLGeocoder()
    
    fileprivate let locationManager: CLLocationManager = {
       let manager = CLLocationManager()
       manager.requestWhenInUseAuthorization()
       return manager
    }()
    
    override func viewDidLoad() {
       super.viewDidLoad()
       setUpMapView()
    }
    
    func setUpMapView() {
       mapView.showsUserLocation = true
       mapView.showsCompass = true
       mapView.showsScale = true
       currentLocation()
    }
    
    func currentLocation() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            if #available(iOS 11.0, *) {
               locationManager.showsBackgroundLocationIndicator = true
            } else {
               // Fallback on earlier versions
            }
            locationManager.startUpdatingLocation()
         }
    
}

extension ViewController: CLLocationManagerDelegate {
     func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last! as CLLocation
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            // Process Response
            self.processResponse(withPlacemarks: placemarks, error: error)
        }
        let currentLocation = location.coordinate
        let coordinateRegion = MKCoordinateRegion(center: currentLocation, latitudinalMeters: 10000, longitudinalMeters: 10000)
        mapView.setRegion(coordinateRegion, animated: true)
        locationManager.stopUpdatingLocation()
     }
     
     func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
     }
    
    private func processResponse(withPlacemarks placemarks: [CLPlacemark]?, error: Error?) {
        // Update View
        

        if let error = error {
            print("Unable to Reverse Geocode Location (\(error))")
            locationLabel.text = "Undetermined Location"

        } else {
            if let placemarks = placemarks, let placemark = placemarks.first {
                locationLabel.text = placemark.administrativeArea
                
            } else {
                print( "No Matching Addresses Found")
            }
        }
    }
}
