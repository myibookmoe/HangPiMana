//
//  LocationViewController.swift
//  HangPiMana
//
//  Created by shah on 17/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import UIKit
import CoreLocation

class LocationViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate {
    
    // MARK: Properties
    
    let geoCoder = CLGeocoder()
    let locationManager = CLLocationManager()
    var locationArray:[LocationItem] = []
    
    // MARK: Outlets

    @IBOutlet weak var tableView: UITableView!
    
    // MARK: Actions
    
    @IBAction func addLocation(_ sender: Any) {
        locationManager.startUpdatingLocation()
    }
    
    // MARK: viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestAlwaysAuthorization()
        locationManager.startMonitoringVisits()
        locationManager.delegate = self
        
    }
    

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? LocationDetailViewController, let indexPath = tableView.indexPathsForSelectedRows?.first {
            let selectedLocationItem = locationArray[indexPath.row]
            destination.locationItem = selectedLocationItem
        }
    }

    
    // MARK: UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locationArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath)
        let locationItem = locationArray[indexPath.row]
        
        cell.textLabel?.text = locationItem.locationDate
        cell.detailTextLabel?.text = locationItem.locationString
        return cell
    }
    
    // MARK: CLLocationManagerDelegate - Visit tracking
    
    func locationManager(_ manager: CLLocationManager, didVisit visit: CLVisit) {
        let clLocation = CLLocation(latitude: visit.coordinate.latitude, longitude: visit.coordinate.longitude)
        geoCoder.reverseGeocodeLocation(clLocation){ placemarks, _ in
          if let place = placemarks?.first{
              self.addToLocationArray(place: place)
          }
        }
    }
    
    // MARK: CLLocationManagerDelegate - Location tracking
        
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else {
            return
          }
        geoCoder.reverseGeocodeLocation(location) { placemarks, _ in
            if let place = placemarks?.first {
                self.addToLocationArray(place: place)
            }
            self.locationManager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let description = "Fail"
        print(description)
    }
    
    // MARK: Helper methods
    
    func addToLocationArray(place:CLPlacemark){
        let locality = place.locality ?? "No Locality"
        let subAdminstrativeArea = place.subAdministrativeArea ?? "No Sub Administrative Area"
        let administrativeArea = place.administrativeArea ?? "No Administrative Area"
        let postalCode = place.postalCode ?? "No Postal Code"
        let country = place.country ?? "No Country"
        let description = "Manual: " + locality + ", " + subAdminstrativeArea + ", " + administrativeArea + ", " + postalCode + ", " + country + "."
        var newLocationItem = LocationItem()
        newLocationItem.locationString = description
        locationArray.append(newLocationItem)
        tableView.reloadData()
    }

}

