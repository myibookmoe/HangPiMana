//
//  LocationViewController.swift
//  HangPiMana
//
//  Created by shah on 17/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import UIKit
import CoreLocation
// CoreLocation is required to use location services

class LocationViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate {
    
    // MARK: Properties
    
    let geoCoder = CLGeocoder()
    // CLGeocoder is used to obtain a location based on coordinates
    let locationManager = CLLocationManager()
    // CLLocationManager uses the GPS to figure out where you area
    var locationArray:[LocationItem] = []
    // Array of LocationItems which is used to populate the Table View
    var noteText : String?
    // When the user updates the note text in LocationDetailViewController,
    // this variable is populated by the unwindToLocationViewController(for:sender:)
    // method
    
    // MARK: Outlets

    @IBOutlet weak var tableView: UITableView!
    // The outlet for the table view
    
    // MARK: Actions
    
    @IBAction func addLocation(_ sender: Any) {
        locationManager.startUpdatingLocation()
    }
    // tells locationManager start updating the user's location
    
    // MARK: viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestAlwaysAuthorization()
        // gets the user's permission to use the user's location
        locationManager.startMonitoringVisits()
        // starts monitoring the user's visits. This is automatic and you don't
        // have to call the startUpdatingLocation() method to get this to work
        // will be triggered when the user is more than 500 meters from the last
        // location
        locationManager.delegate = self
        // LocationViewController is the delegate for locationManager
        loadLocations()
        // loads the list of locations from a JSON file stored in the Documents
        // directory
    }
    

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // called when going from the Location screen to the Location Detail screen
        if let destination = segue.destination as? LocationDetailViewController, let indexPath = tableView.indexPathsForSelectedRows?.first {
            // when going from the Location screen to the LocationDetail screen,
            // get the indexPath of the tapped row
            let selectedLocationItem = locationArray[indexPath.row]
            // assign the corresponding locationArray item to selectedLocationItem
            destination.locationItem = selectedLocationItem
            // pass selectedLocationItem to LocationDetailViewController
        }
    }
    
    @IBAction func unwindToLocationViewController(segue:UIStoryboardSegue) {
        // called when going from Location Detail screen to the Location screen
        if let locDet = segue.source as? LocationDetailViewController {
            noteText = locDet.noteText
            // passes the note text from the Location Detail screen to noteText
            if let note = noteText, let tappedRow = tableView.indexPathForSelectedRow {
                // if noteText is populated, get the row that was originally tapped
                locationArray[tappedRow.row].locationNote = note
                // set the note property for the corresponding LocationItem
                saveLocations()
                // save the locationArray to the Document directory as a JSON file
            }
        }
    }

    
    // MARK: UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // number of rows to be displayed
        return locationArray.count
        // are the same as number of items in locationArray
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // what to display in each row
        let cell = tableView.dequeueReusableCell(withIdentifier: "locationCell", for: indexPath)
        // get or reuse a cell with the locationCell identifier
        let locationItem = locationArray[indexPath.row]
        // get the corresponding LocationItem from locationArray
        cell.textLabel?.text = locationItem.locationDate
        // set the text label for the table view cell
        cell.detailTextLabel?.text = locationItem.locationMode + ": " + locationItem.locationString
        // set the detail text label for the table view cell
        return cell
        // return the cell
    }
    
    // MARK: CLLocationManagerDelegate - Visit tracking
    
    func locationManager(_ manager: CLLocationManager, didVisit visit: CLVisit) {
        // called whenever a new visit is generated
        let clLocation = CLLocation(latitude: visit.coordinate.latitude, longitude: visit.coordinate.longitude)
        // get the coordinates from the returned location
        geoCoder.reverseGeocodeLocation(clLocation){ placemarks, _ in
          if let place = placemarks?.first{
            // reverse geocode the location to generate a placemark
              self.addToLocationArray(place: place, mode: "Auto")
            // calls the addToLocationArray method to add a LocationItem
            // with the placemark data to locationArray
          }
        }
    }
    
    // MARK: CLLocationManagerDelegate - Location tracking
        
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // called whenever the user's location is updated
        guard let location = locations.first else {
            // get the first location from the array of returned locations
            // early exit if not the first
            return
          }
        geoCoder.reverseGeocodeLocation(location) { placemarks, _ in
            if let place = placemarks?.first {
                // reverse geocode the location to generate a placemark
                self.addToLocationArray(place: place, mode: "Manual")
                // calls the addToLocationArray method to add a LocationItem
                // with the placemark data to locationArray
            }
            self.locationManager.stopUpdatingLocation()
            // stop updating user location, otherwise it will continuously add
            // LocationsItems to the locationArray
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // executed if locationManager can't determine the user's location
        let description = "Fail"
        print(description)
    }
    
    // MARK: Helper methods
    
    func addToLocationArray(place:CLPlacemark, mode: String){
        // populates a LocationItem with the information from the placemark
        let newLocationItem = LocationItem(lD: "new", lN: place.name ?? " ", lICC: place.isoCountryCode ?? " ", lC: place.country ?? " ", lPC: place.postalCode ?? " ", lAA: place.administrativeArea ?? " ", lSAA: place.subAdministrativeArea ?? " ", lL: place.locality ?? " ", lSL: place.subLocality ?? " ", lT: place.thoroughfare ?? " ", lST: place.subThoroughfare ?? " ", lM: mode, lNt: "")
        
        locationArray.append(newLocationItem)
        // adds the LocationItem to the locationArray array
        saveLocations()
        // writes locationArray to the Documents directory
        // as a JSON file
        tableView.reloadData()
        // redraw the table view
    }
    
    @IBAction func exportToJSON() {
        let fileURL = try? FileManager.default
        .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        .appendingPathComponent("locations.json")
        // gets the path where the JSON file is stored
        if let tempURL = fileURL {
            var filesToShare = [Any]()
            filesToShare.append(tempURL)
            // gets the JSON file to be shared
            let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)
            self.present(activityViewController, animated: true, completion: nil)
            // presents the file sharing dialog
        }
    }
    
    private func saveLocations() {
        do {
            let fileURL = try FileManager.default
            .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("locations.json")
            // gets the path where the file will be saved
            let jsonData = try! JSONEncoder().encode(locationArray)
            // encode the locationArray to a JSON file
            try jsonData.write(to: fileURL)
            // writes the JSON file to the path
        } catch {
            print(error)
        }
    }
    
    private func loadLocations() {
        let fileURL = try? FileManager.default
                .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                .appendingPathComponent("locations.json")
        // gets the path where the file is stored
        
        if let tempURL = fileURL, let tempData = try? Data(contentsOf: tempURL), let tempArray = try? JSONDecoder().decode([LocationItem].self, from: tempData) {
                locationArray += tempArray
            // loads the file and appends it to locationArray if it exists
        } else {
            locationArray = []
            // if not, start with an empty locationArray
        }
    }

}

