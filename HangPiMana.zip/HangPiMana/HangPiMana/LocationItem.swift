//
//  LocationItem.swift
//  HangPiMana
//
//  Created by shah on 18/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import Foundation

struct LocationItem: Codable {
    // Codable makes it possible to convert to and from JSON
    
    // MARK: class properties
    
    static let dateFormatter: DateFormatter = {
      let formatter = DateFormatter()
      formatter.dateStyle = .short
      formatter.timeStyle = .short
      return formatter
    }()
    // used to convert the Date object to a human readable string

    // MARK: instance properties
    var locationDate: String
    var locationName: String
    var locationISOCountryCode: String
    var locationCountry: String
    var locationPostalCode: String
    var locationAdministrativeArea: String
    var locationSubAdministrativeArea: String
    var locationLocality: String
    var locationSubLocality: String
    var locationThoroughfare: String
    var locationSubThoroughfare: String
    var locationMode: String
    var locationNote: String
    // based on the information provided by the placemark
    
    var locationString: String {
         return self.locationLocality + ", " + self.locationSubAdministrativeArea + ", " + self.locationAdministrativeArea + ", " + self.locationPostalCode + ", " + self.locationCountry + "."
     }
    // computed property which generates a string from the LocationItem's properties
    
    
    // MARK: Initializer
    
    init(lD:String, lN:String, lICC:String, lC:String, lPC:String, lAA:String, lSAA:String, lL:String, lSL:String, lT:String, lST:String, lM:String, lNt:String) {
        
    
        if lD == "new" {
            self.locationDate = LocationItem.dateFormatter.string(from: Date())
        } else {
            self.locationDate = lD
        }
        // when the + button is tapped, set locationDate from the current data
        self.locationName = lN
        self.locationISOCountryCode = lICC
        self.locationCountry = lC
        self.locationPostalCode = lPC
        self.locationAdministrativeArea = lAA
        self.locationSubAdministrativeArea = lSAA
        self.locationLocality = lL
        self.locationSubLocality = lSL
        self.locationThoroughfare = lT
        self.locationSubThoroughfare = lST
        self.locationMode = lM
        self.locationNote = lNt
    }
}
