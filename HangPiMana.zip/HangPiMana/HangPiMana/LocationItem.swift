//
//  LocationItem.swift
//  HangPiMana
//
//  Created by shah on 18/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import Foundation

struct LocationItem {
    
    // MARK: struct properties
    
    static let dateFormatter: DateFormatter = {
      let formatter = DateFormatter()
      formatter.dateStyle = .medium
      formatter.timeStyle = .medium
      return formatter
    }()

    // MARK: instance properties
    let locationDate = LocationItem.dateFormatter.string(from: Date())
    var locationString = ""
    
}
