//
//  LocationDetailViewController.swift
//  HangPiMana
//
//  Created by shah on 18/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import UIKit

class LocationDetailViewController: UIViewController {
    
    // MARK: Properties
    
    var locationItem: LocationItem?
    
    // MARK: Outlets
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    
    // MARK: viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let tempLocationItem = locationItem {
            dateLabel.text = tempLocationItem.locationDate
            locationLabel.text = tempLocationItem.locationString
        } else {
            print("No location")
        }
    }
}
