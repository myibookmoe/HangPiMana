//
//  LocationDetailViewController.swift
//  HangPiMana
//
//  Created by shah on 18/04/2020.
//  Copyright © 2020 Tomafuwi Productions Sdn. Bhd. All rights reserved.
//

import UIKit

class LocationDetailViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: Properties
    
    var locationItem: LocationItem?
    // holds the LocationItem used to populate this view
    var noteText: String?
    // holds the text the user enters in noteTextField
    
    // MARK: Outlets
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var modeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var iSOCountryCodeLabel: UILabel!
    @IBOutlet weak var postalCodeLabel: UILabel!
    @IBOutlet weak var adminAreaLabel: UILabel!
    @IBOutlet weak var subAdminAreaLabel: UILabel!
    @IBOutlet weak var localityLabel: UILabel!
    @IBOutlet weak var subLocalityLabel: UILabel!
    @IBOutlet weak var thoroughfareLabel: UILabel!
    @IBOutlet weak var subThoroughfareLabel: UILabel!
    @IBOutlet weak var noteTextField: UITextField!
    
    // MARK: - Navigation

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Location Detail"
        // Sets the title in the Navigation Bar
        if let tempLocationItem = locationItem {
            dateLabel.text = tempLocationItem.locationDate
            modeLabel.text = tempLocationItem.locationMode
            nameLabel.text = tempLocationItem.locationName
            iSOCountryCodeLabel.text = tempLocationItem.locationISOCountryCode
            postalCodeLabel.text = tempLocationItem.locationPostalCode
            adminAreaLabel.text = tempLocationItem.locationAdministrativeArea
            subAdminAreaLabel.text = tempLocationItem.locationSubAdministrativeArea
            localityLabel.text = tempLocationItem.locationLocality
            subLocalityLabel.text = tempLocationItem.locationSubLocality
            thoroughfareLabel.text = tempLocationItem.locationThoroughfare
            subThoroughfareLabel.text = tempLocationItem.locationSubThoroughfare
            noteTextField.text = tempLocationItem.locationNote
            // populates the screen if the locationItem property is set
        } else {
            print("No location")
        }
    }
    
    // MARK: - Text Field Delegate
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        // called after the user has finished editing the text in noteTextField
        if let tempNote = noteTextField.text {
            noteText = tempNote
            // sets the noteText property if there is text in noteTextField
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // called when the user taps the Return key
        textField.resignFirstResponder()
        // makes the on screen keyboard go away
        return true
    }
}
